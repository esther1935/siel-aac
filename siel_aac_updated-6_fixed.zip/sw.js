const CACHE_NAME = "siel-aac-app-sielFix20260629";
const IMAGE_CACHE = "siel-aac-image-cache-v4";

const APP_SHELL = [
  "./",
  "./index.html",
  "./styles.css?v=sielSyncOverwrite20260628",
  "./app.js?v=sielSyncOverwrite20260628",
  "./manifest.webmanifest?v=sielSyncOverwrite20260628"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key.startsWith("siel-aac-app-") && key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

function looksLikeImageRequest(req, url) {
  return req.destination === "image"
    || /\.(png|jpg|jpeg|webp|gif|svg)(\?|$)/i.test(url.pathname)
    || url.hostname.includes("firebasestorage.googleapis.com")
    || url.pathname.includes("/o/");
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  if (looksLikeImageRequest(req, url)) {
    event.respondWith(
      caches.open(IMAGE_CACHE).then(async (cache) => {
        const cached = await cache.match(req) || await cache.match(req.url);

        // 오프라인이면 캐시만 사용
        if (!self.navigator.onLine) {
          return cached || Response.error();
        }

        // 온라인 + 캐시 있음: 즉시 반환 후 백그라운드 갱신 (stale-while-revalidate)
        if (cached) {
          fetch(req, { cache: "no-store" })
            .then(res => {
              if (res && (res.ok || res.type === "opaque")) {
                cache.put(req, res);
              }
            })
            .catch(() => {});
          return cached;
        }

        // 온라인 + 캐시 없음: 네트워크에서 가져와 저장
        try {
          const response = await fetch(req, { cache: "no-store" });
          if (response && (response.ok || response.type === "opaque")) {
            await cache.put(req, response.clone());
          }
          return response;
        } catch (e) {
          return Response.error();
        }
      })
    );
    return;
  }

  if (url.hostname.includes("googleapis.com") || url.hostname.includes("firebase")) {
    return;
  }

  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req).then((response) => {
        if (response && response.ok && url.origin === self.location.origin) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy));
        }
        return response;
      }).catch(() => cached);

      return cached || network;
    })
  );
});
